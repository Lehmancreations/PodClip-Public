## PodClip

Controls the PodClip Mac app over OSC (UDP).

**In PodClip:** make sure the **OSC** button (top bar) shows green / enabled. The default port is **9000**.

**Here:** set *PodClip address* to the Mac running PodClip (`127.0.0.1` if Companion runs on the same Mac) and the same port.

### Actions
- **Recording: start / stop / toggle**
- **Clip: play** by number (1 = first soundboard button, same order as ⌘1–⌘9) or by name
- **Clip: play / pause / resume** and **restart** (play uses the pad's own "When Clicked Again" setting in PodClip)
- **Clip: stop** one clip (number) or all clips (0)
- **Clip: capture the last N seconds** of the live recording as a new soundboard clip (works while PodClip is recording)

### Feedback & variables
The module subscribes to PodClip, so buttons can light up while recording or while a clip plays.
Variables: `recording`, `elapsed`, `clip_count`, `clip_1_name` … `clip_32_name`.

### Presets
Ready-made buttons for record/stop and clips 1–16 (name shown on the button, turns green while playing).
